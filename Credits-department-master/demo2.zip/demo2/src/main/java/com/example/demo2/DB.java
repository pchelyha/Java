package com.example.demo2;


import java.sql.*;
import java.util.ArrayList;

public class DB {

    // Данные для подключения к локальной базе данных
    private final String HOST = "192.168.13.100";
    private final String PORT = "3306";
    private final String DB_NAME = "user13";
    private final String LOGIN = "user13"; // Если OpenServer, то здесь mysql напишите
    private final String PASS = "41225"; // Если OpenServer, то здесь mysql напишите

    private Connection dbConn = null;

    // Метод для подключения к БД с использованием значений выше
    private Connection getDbConnection() throws ClassNotFoundException, SQLException {
        String connStr = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_NAME;
        Class.forName("com.mysql.cj.jdbc.Driver");

        dbConn = DriverManager.getConnection(connStr, LOGIN, PASS);
        return dbConn;
    }
    public ArrayList<String> Login() throws SQLException, ClassNotFoundException {
        String sql = "SELECT Login FROM user13.Staff order by idStaff";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> login = new ArrayList<>();
        while(res.next())
            login.add(res.getString("Login"));

        return login;
    }
    public ArrayList<String> Password() throws SQLException, ClassNotFoundException {
        String sql = "SELECT Password FROM user13.Staff order by idStaff";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("Password"));

        return password;
    }
    public ArrayList<String> FIO() throws SQLException, ClassNotFoundException {
        String sql = "SELECT FIO FROM user13.Staff order by idStaff";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("FIO"));

        return password;
    }
    public ArrayList<String> Post() throws SQLException, ClassNotFoundException {
        String sql = "SELECT Post FROM user13.Staff order by idStaff";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("Post"));

        return password;
    }
    public ArrayList<String> ID() throws SQLException, ClassNotFoundException {
        String sql = "SELECT idOrders FROM user13.Orders order by idOrders";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("idOrders"));

        return password;
    }
    public ArrayList<String> Code() throws SQLException, ClassNotFoundException {
        String sql = "SELECT Code_of_order FROM user13.Orders order by idOrders";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("Code_of_order"));

        return password;
    }
    public ArrayList<String> Date() throws SQLException, ClassNotFoundException {
        String sql = "SELECT Date_of_creation FROM user13.Orders order by idOrders";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("Date_of_creation"));

        return password;
    }
    public ArrayList<String> Time() throws SQLException, ClassNotFoundException {
        String sql = "SELECT Time_of_order FROM user13.Orders order by idOrders";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("Time_of_order"));

        return password;
    }
    public ArrayList<String> CodeK() throws SQLException, ClassNotFoundException {
        String sql = "SELECT Code_of_client FROM user13.Orders order by idOrders";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("Code_of_client"));

        return password;
    }
    public ArrayList<String> Servic() throws SQLException, ClassNotFoundException {
        String sql = "SELECT Services FROM user13.Orders order by idOrders";

        Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        ArrayList<String> password = new ArrayList<>();
        while(res.next())
            password.add(res.getString("Services"));

        return password;
    }
}
