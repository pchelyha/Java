package com.example.demo2;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Stream;

public class Controller  {
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private  TextField l;


    @FXML
    private  PasswordField p;
    @FXML
    private CheckBox glaz;
    @FXML
    private TextField pa;

    @FXML
    private Label oshibka;

    @FXML
    private  Button vhod;
    DB db = null;
    MainShtrihCode sh = null;
    int count = 0;

    @FXML
    void initialize() {
    oshibka.setVisible(false);



        // Инициируем объект
        sh = new MainShtrihCode();
        db = new DB();

        // Обработчик события. Сработает при нажатии на кнопку
        vhod.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Timer tm = new Timer();
                l.setText("Ivanov@namecomp.ru");
                p.setText("2L6KZG");
                   voiti();
                   dan();

                   if (count==3) {
                    p.setVisible(false);
                    pa.setVisible(false);
                    glaz.setVisible(false);
                    l.setVisible(false);
                    oshibka.setVisible(true);
                    tm.schedule(task, 10000l);

                }



            }
        });

    }

    public void maska() {

        if (glaz.isSelected()) {
            pa.setText(p.getText());
            p.setVisible(false);
            pa.setVisible(true);
        } else {
            p.setText(pa.getText());
            pa.setVisible(false);
            p.setVisible(true);
        }
    }

    TimerTask task = new TimerTask(){
       public void run() {
            p.setVisible(true);
            pa.setVisible(true);
            glaz.setVisible(true);
            l.setVisible(true);
            oshibka.setVisible(false);
        }
    };
@FXML
   public  int voiti() {
      int b =0;
        int c =0;
        int d =0;
        int g = 0;


        try{
            String log = l.getText();
            String pass = p.getText();
            ArrayList<String> login = db.Login();
            ArrayList<String> password = db.Password();
            ArrayList<String> FIO = db.FIO();
            ArrayList<String> Post = db.Post();
            ArrayList<String> Tablica = db.Tablica();



            for (int i=0; i<login.size();i++) {
                if (log.equals(login.get(i))) {
                    b = 1;
                    d=i;
                }

            }
            for(int i=0; i<password.size();i++){
                if (pass.equals(password.get(i))){
                    c = 1;
                    g=i;

                }


            }

            if (b==1 && c== 1 && d==g ){
                System.out.print(Tablica);


                Stage stage = new Stage();

                stage.setTitle("Бархатные холмы");
                VBox vBox = new VBox();
                Label nick = new Label();
                vBox.setAlignment(Pos.TOP_CENTER);
                vBox.getChildren().add(nick);
                nick.setText(FIO.get(g));
                InputStream input = getClass().getResourceAsStream("/img/"+FIO.get(g).split(" ")[0]+".jpeg");
                Image image = new Image(input, 50,50,false,true);
                ImageView imageView = new ImageView(image);
                vBox.getChildren().add(imageView);
                Label post = new Label();
                vBox.getChildren().add(post);
                post.setText("Роль: " + Post.get(g));
                Button bt = new Button("Сформировать штрих-код");

                    bt.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
                        @Override
                        public void handle(MouseEvent mouseEvent) {
                            try {
                                sh.start(stage);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });



                vBox.getChildren().add(bt);
                Button pd = new Button("Сформировать pdf");

                pd.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        try {
                            pdf();
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                });



                vBox.getChildren().add(pd);
                Scene scene = new Scene(vBox, 250, 400);
                stage.setScene(scene);
                stage.show();
               Stage stage1 = (Stage) vhod.getScene().getWindow();
               stage1.close();




                return d;


            } else {
                count++;
                return 0;
            }
        } catch (SQLException e) {

            e.printStackTrace();
        } catch (ClassNotFoundException e) {

            e.printStackTrace();
        }

    return 1;
    }
  public  void dan(){
       vhod.setUserData(l.getText());
  }
  public void kartinka() throws FileNotFoundException, DocumentException, URISyntaxException , NullPointerException{

      Path path = Paths.get("src/main/resources/img/Иванов.jpeg");
      System.out.println(path);
      Document document = new Document();
      PdfWriter.getInstance(document, new FileOutputStream("iTextImageExample.pdf"));
      document.open();
      com.itextpdf.text.Image img=null;
      try {
          img = com.itextpdf.text.Image.getInstance(path.toAbsolutePath().toString());
      } catch (IOException e) {
          throw new RuntimeException(e);
      }
      document.add(img);
      document.close();
  }
  public  void pdf() throws FileNotFoundException, DocumentException {
      Document document = new Document();
      PdfWriter.getInstance(document, new FileOutputStream("iTextTable.pdf"));

      document.open();

      PdfPTable table = new PdfPTable(9);
      addTableHeader(table);
      addRows(table);


      document.add(table);
      document.close();
  }
    private void addTableHeader(PdfPTable table) {
        Stream.of("ID", "Code of order", "Date of creation", "Time of order", "Code of client", "Services", "State", "Date of closed", "Time of rental")
                .forEach(columnTitle -> {
                    PdfPCell header = new PdfPCell();
                    header.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    header.setBorderWidth(1);
                    header.setPhrase(new Phrase(columnTitle));
                    table.addCell(header);
                });
    }
    private void addRows(PdfPTable table) {
        table.addCell("z");
        table.addCell("z");
        table.addCell("z");
        table.addCell("z");
        table.addCell("z");
        table.addCell("z");
        table.addCell("z");
        table.addCell("z");
        table.addCell("z");
    }

}