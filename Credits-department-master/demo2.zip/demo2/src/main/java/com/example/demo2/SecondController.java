package com.example.demo2;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/*
import static com.example.demo2.Controller.voiti;
*/
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;

public class SecondController {
    @FXML
    private Label nick;
    @FXML
    private Button bt;
    DB db = null;
    @FXML
    void initialize() {
        db = new DB();
        bt.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {

            }
        });
    }

@FXML
    void Imy() throws SQLException, ClassNotFoundException {
        Controller cr = null;


    }
}

